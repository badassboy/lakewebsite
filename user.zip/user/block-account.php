<?php
include("../database.php");

$db = DB();

if (isset($_GET['trash'])) {

	$trashed_id = $_GET['trash'];

	// update the status
	$sql = "UPDATE transfers SET blocked=1 WHERE id=$trashed_id";
	$stmt= $db->prepare($sql);
	$result = $stmt->execute([$trashed_id]);

	if ($stmt->rowCount()>0) {
		echo '<div class="alert alert-success" role="alert">Account blocked</div>';
	}

}


?>